package com.ca_dreamers.cadreamers.fragments.address.update_address;

import androidx.lifecycle.ViewModel;

public class UpdateAddressViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}