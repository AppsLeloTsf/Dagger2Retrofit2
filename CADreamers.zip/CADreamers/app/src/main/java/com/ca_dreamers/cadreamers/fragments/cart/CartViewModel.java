package com.ca_dreamers.cadreamers.fragments.cart;

import androidx.lifecycle.ViewModel;

public class CartViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}