package com.ca_dreamers.cadreamers.fragments.profile;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.FileProvider;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.ca_dreamers.cadreamers.activity.MainActivity;
import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.profile.ModelUserInfo;
import com.ca_dreamers.cadreamers.models.profile.profile_edit.ModelProfileEdit;
import com.ca_dreamers.cadreamers.models.profile.user_image.ModelProfileImage;
import com.ca_dreamers.cadreamers.models.profile.user_image.update_image.ModelUpdateImage;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.ca_dreamers.cadreamers.utils.Constant.TAG;

public class ProfileFragment extends Fragment {

    private ProfileViewModel mViewModel;
    private SharedPrefManager sharedPrefManager;

    private Context context;
    private String strUserId;
    private String strUserName;
    private String strUserNameEdited;
    private String strEmail;
    private String strPhone;
    private String strState;
    private String strStateEdited;
    private String strPinCode;
    private String strPinCodeEdited;
    private String strAddress;
    private String strAddressEdited;

    @BindView(R.id.ivProfilePic)
    protected ImageView ivProfilePic;
    @BindView(R.id.ivProfilePicEdit)
    protected ImageView ivProfilePicEdit;
    @BindView(R.id.llProfileShow)
    protected LinearLayout llProfileShow;
    @BindView(R.id.ivProfileEdit)
    protected ImageView ivProfileEdit;
    @BindView(R.id.tvUserNameProfile)
    protected TextView tvUserNameProfile;
    @BindView(R.id.tvEmailProfile)
    protected TextView tvEmailProfile;
    @BindView(R.id.tvStateProfile)
    protected TextView tvStateProfile;
    @BindView(R.id.tvPinProfile)
    protected TextView tvPinProfile;
    @BindView(R.id.tvAddressProfile)
    protected TextView tvAddressProfile;
    @BindView(R.id.tvPhoneProfile)
    protected TextView tvPhoneProfile;

    @BindView(R.id.llProfileEdit)
    protected LinearLayout llProfileEdit;
    @BindView(R.id.etUserNameProfileEdit)
    protected EditText etUserNameProfileEdit;
    @BindView(R.id.tvEmailProfileEdit)
    protected TextView tvEmailProfileEdit;
    @BindView(R.id.etStateProfileEdit)
    protected EditText etStateProfileEdit;
    @BindView(R.id.etPinProfileEdit)
    protected EditText etPinProfileEdit;
    @BindView(R.id.etAddressProfileEdit)
    protected EditText etAddressProfileEdit;
    @BindView(R.id.tvPhoneProfileEdit)
    protected TextView tvPhoneProfileEdit;
    @BindView(R.id.btnSubmitProfileEdit)
    protected AppCompatButton btnSubmitProfileEdit;

    public static ProfileFragment newInstance() {
        return new ProfileFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        ButterKnife.bind(this, view);
        context = getContext();
        sharedPrefManager = new SharedPrefManager(context);
        strUserId = sharedPrefManager.getUserId();
        llProfileEdit.setVisibility(View.GONE);
        llProfileShow.setVisibility(View.VISIBLE);
        callProfileImageApi(context);
        callProfileApi();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);
        // TODO: Use the ViewModel
    }
    private void callProfileImageApi(Context context){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("userid", strUserId);
            paramObject.put("encryptfile", "abc");
            paramObject.put("type", "");


            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelProfileImage> call = api.getUserImage(gsonObject);
            call.enqueue(new Callback<ModelProfileImage>() {
                @Override
                public void onResponse(Call<ModelProfileImage> call, Response<ModelProfileImage> response) {
                    ModelProfileImage modelProfileImage = response.body();
                    String strUserImage = modelProfileImage.getData().getFileUrl();
                        Glide.with(context).load(strUserImage).into(ivProfilePic);
                        Glide.with(context).load(strUserImage).into(ivProfilePicEdit);

                }

                @Override
                public void onFailure(Call<ModelProfileImage> call, Throwable t) {

                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void callProfileApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("userid", sharedPrefManager.getUserId());


            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelUserInfo> call = api.getUserInfo(gsonObject);
            call.enqueue(new Callback<ModelUserInfo>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onResponse(Call<ModelUserInfo> call, Response<ModelUserInfo> response) {
                    ModelUserInfo modelUserInfo = response.body();
                    strUserName = modelUserInfo.getData().getUsername();
                    strEmail = modelUserInfo.getData().getEmail();
                    strPhone = modelUserInfo.getData().getPhone();
                    strState = modelUserInfo.getData().getState();
                    strPinCode = modelUserInfo.getData().getPincode();
                    strAddress = modelUserInfo.getData().getAddress();
                    tvUserNameProfile.setText(strUserName);
                    tvEmailProfile.setText(strEmail);
                    tvStateProfile.setText(strState);
                    tvPinProfile.setText(strPinCode);
                    tvAddressProfile.setText(strAddress);
                    tvPhoneProfile.setText(strPhone);

                    etUserNameProfileEdit.setText(strUserName);
                    tvEmailProfileEdit.setText(strEmail);
                    etStateProfileEdit.setText(strState);
                    etPinProfileEdit.setText(strPinCode);
                    etAddressProfileEdit.setText(strAddress);
                    tvPhoneProfileEdit.setText(strPhone);



                }

                @Override
                public void onFailure(Call<ModelUserInfo> call, Throwable t) {

                    Log.d("TSF_PRO", "Failure: "+t.getMessage());
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void callProfileEditApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();

            strUserNameEdited = etUserNameProfileEdit.getText().toString().trim();
            strStateEdited = etStateProfileEdit.getText().toString().trim();
            strPinCodeEdited = etPinProfileEdit.getText().toString().trim();
            strAddressEdited = etAddressProfileEdit.getText().toString().trim();
            paramObject.put("username", strUserNameEdited);
            paramObject.put("email", strEmail);
            paramObject.put("phone", strPhone);
            paramObject.put("state", strStateEdited);
            paramObject.put("userid", strUserId);
            paramObject.put("pincode", strPinCodeEdited);
            paramObject.put("address", strAddressEdited);


            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelProfileEdit> call = api.getUserInfoEdit(gsonObject);
            call.enqueue(new Callback<ModelProfileEdit>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onResponse(Call<ModelProfileEdit> call, Response<ModelProfileEdit> response) {
                    ModelProfileEdit modelUserInfo = response.body();
                    if (modelUserInfo.getStatus().getStatuscode().equals("200")) {
                        llProfileEdit.setVisibility(View.GONE);
                        llProfileShow.setVisibility(View.VISIBLE);
                       // Toast.makeText(getContext(), modelUserInfo.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ModelProfileEdit> call, Throwable t) {

                    Log.d("TSF_PRO", "Failure: "+t.getMessage());
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.btnSubmitProfileEdit)
    public void btnSubmitProfileEditClicked(){
        callProfileEditApi();
        callImageUpdateApi();


    }
    @OnClick(R.id.ivProfileEdit)
    public void ivProfileEditClicked(){
        llProfileEdit.setVisibility(View.VISIBLE);
        llProfileShow.setVisibility(View.GONE);


    }

    private void selectImage() {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");

                    Uri photoURI = FileProvider.getUriForFile(getContext(), getActivity().getApplicationContext().getPackageName() + ".provider", f);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    startActivityForResult(intent, 1);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @OnClick(R.id.ivProfilePicEdit)
    public void ivProfilePicClicked(){
        Dexter.withActivity(getActivity())
                .withPermissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            selectImage();
                        }

                        if (report.isAnyPermissionPermanentlyDenied()) {
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    Bitmap bitmap;
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(),
                            bitmapOptions);
                    ivProfilePicEdit.setImageBitmap(bitmap);
                    String path = android.os.Environment
                            .getExternalStorageDirectory()
                            + File.separator
                            + "Phoenix" + File.separator + "default";
                    f.delete();
                    OutputStream outFile = null;
                    File file = new File(path, String.valueOf(System.currentTimeMillis()) + ".jpg");
                    try {
                        outFile = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 10, outFile);
                        outFile.flush();
                        outFile.close();

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getActivity().getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                Log.w(TAG, picturePath+"");
                ivProfilePicEdit.setImageBitmap(thumbnail);

            }
        }
    }
    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(getString(R.string.dialog_permission_title));
        builder.setMessage(getString(R.string.dialog_permission_message));
        builder.setPositiveButton(getString(R.string.go_to_settings), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(android.R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();

    }

    // navigating user to app settings
    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    private void callImageUpdateApi(){
        String strProPic = null;
        BitmapDrawable drawable = (BitmapDrawable) ivProfilePicEdit.getDrawable();
        if (ivProfilePicEdit.getDrawable() != null){
        Bitmap bitmap = drawable.getBitmap();
            strProPic = BitMapToString(bitmap);
        }
        else {
            strProPic = "abc";
        }
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("userid", strUserId);
            paramObject.put("encryptfile", strProPic);
            paramObject.put("type", "update");

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelUpdateImage> call = api.updateImage(gsonObject);
            call.enqueue(new Callback<ModelUpdateImage>() {
                @Override
                public void onResponse(Call<ModelUpdateImage> call, Response<ModelUpdateImage> response) {
                    ModelUpdateImage modelProfileImage = response.body();

                    if (modelProfileImage.getStatus().getStatuscode().equals("200")){
                        llProfileEdit.setVisibility(View.GONE);
                        llProfileShow.setVisibility(View.VISIBLE);
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).callProfileImageApi();
                        }
                        callProfileImageApi(context);
                    }
                    Toast.makeText(context, "Profile updated successfully", Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onFailure(Call<ModelUpdateImage> call, Throwable t) {

                    Log.d(TAG, "Update Failure: "+t.getMessage());
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public String BitMapToString(Bitmap bitmap){
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,10, baos);
        byte [] b=baos.toByteArray();
        String temp= Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

}