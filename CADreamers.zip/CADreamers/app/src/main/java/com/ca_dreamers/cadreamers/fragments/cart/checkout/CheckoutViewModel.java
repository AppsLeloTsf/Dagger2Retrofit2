package com.ca_dreamers.cadreamers.fragments.cart.checkout;

import androidx.lifecycle.ViewModel;

public class CheckoutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}