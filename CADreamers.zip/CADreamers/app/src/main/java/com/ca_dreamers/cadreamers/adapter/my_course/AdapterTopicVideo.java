package com.ca_dreamers.cadreamers.adapter.my_course;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.activity.PdfActivity;
import com.ca_dreamers.cadreamers.activity.VimeoPlayerActivity;
import com.ca_dreamers.cadreamers.models.my_orders.course_details.chapters.topics.Content;
import com.ca_dreamers.cadreamers.utils.Constant;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class AdapterTopicVideo extends RecyclerView.Adapter<AdapterTopicVideo.TopicViewHolder> {

    private final Context tContext;
    private final List<Content> tModels;



    public AdapterTopicVideo(List<Content> tModels, Context tContext) {
        this.tModels = tModels;
        this.tContext = tContext;

    }

    @NonNull
    @Override
    public TopicViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_my_course_video, viewGroup, false);
        return new TopicViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TopicViewHolder topicViewHolder, final int i) {
        final Content tModel = tModels.get(i);
        final String strCourseTitle = tModel.getTitle();

            topicViewHolder.tvTopicContentTitle.setText(strCourseTitle);

        if (tModel.getCtype().equals("video")) {
            topicViewHolder.tvTopicContentTitle.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_video, 0, 0, 0);
        }else if (tModel.getCtype().equals("docs")){
            topicViewHolder.tvTopicContentTitle.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_pdf, 0, 0, 0);

        }
            topicViewHolder.rlChapterTopic.setOnClickListener(v -> {

                Intent intent;
                if (tModel.getCtype().equals("video")) {
                    intent = new Intent(tContext, VimeoPlayerActivity.class);
                    intent.putExtra(Constant.CONTENT_ID, tModel.getId());
                    intent.putExtra(Constant.CONTENT_TITLE, tModel.getTitle());
                    intent.putExtra(Constant.CONTENT_EMBED, tModel.getVideoContent().getEmbed());
                    tContext.startActivity(intent);
                }else if(tModel.getCtype().equals("docs")){
                    intent = new Intent(tContext, PdfActivity.class);
                    intent.putExtra(Constant.BOOKS_PDF_URL, tModel.getDocContent().getFilePath());
                    tContext.startActivity(intent);
                }


            });

    }

    @Override
    public int getItemCount() {
        return tModels.size();
    }

    public static class TopicViewHolder extends RecyclerView.ViewHolder{
        @SuppressLint("NonConstantResourceId")
        @BindView(R.id.tvTopicContentTitle)
        protected TextView tvTopicContentTitle;

        @SuppressLint("NonConstantResourceId")
        @BindView(R.id.rlChapterTopic)
        protected RelativeLayout rlChapterTopic;
        public TopicViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
