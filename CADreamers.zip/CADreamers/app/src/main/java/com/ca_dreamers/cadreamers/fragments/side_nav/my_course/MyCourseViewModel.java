package com.ca_dreamers.cadreamers.fragments.side_nav.my_course;

import androidx.lifecycle.ViewModel;

public class MyCourseViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}