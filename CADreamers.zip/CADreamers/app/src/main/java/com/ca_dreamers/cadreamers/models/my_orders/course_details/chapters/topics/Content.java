package com.ca_dreamers.cadreamers.models.my_orders.course_details.chapters.topics;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Content {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("ctype")
    @Expose
    private String ctype;
    @SerializedName("video_content")
    @Expose
    private VideoContent videoContent;
    @SerializedName("doc_content")
    @Expose
    private DocContent docContent;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCtype() {
        return ctype;
    }

    public void setCtype(String ctype) {
        this.ctype = ctype;
    }

    public VideoContent getVideoContent() {
        return videoContent;
    }

    public void setVideoContent(VideoContent videoContent) {
        this.videoContent = videoContent;
    }

    public DocContent getDocContent() {
        return docContent;
    }

    public void setDocContent(DocContent docContent) {
        this.docContent = docContent;
    }

}
