package com.ca_dreamers.cadreamers.fragments.address;

import androidx.lifecycle.ViewModel;

public class AddressViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}