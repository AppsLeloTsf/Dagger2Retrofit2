package com.ca_dreamers.cadreamers.fragments.notification.notification_read;

import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ca_dreamers.cadreamers.activity.MainActivity;
import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.notification.notification_read.ModelNotificationRead;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.ca_dreamers.cadreamers.utils.Constant.TAG;

public class FragmentNotificationRead extends Fragment {

    private SharedPrefManager sharedPrefManager;
    private String strUserId;
    private Context context;
    private String strNotificationId;
    private String strNotificationTitle;
    private String strNotification;
    private String strNotificationDate;

    @BindView(R.id.tvNotificationReadTitle)
    protected TextView tvNotificationReadTitle;
    @BindView(R.id.tvNotificationRead)
    protected TextView tvNotificationRead;
    @BindView(R.id.tvNotificationReadDate)
    protected TextView tvNotificationReadDate;


    private FragmentNotificationReadViewModel mViewModel;

    public static FragmentNotificationRead newInstance() {
        return new FragmentNotificationRead();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notification_read, container, false);
        ButterKnife.bind(this, view);
        context = view.getContext();
        sharedPrefManager = new SharedPrefManager(getContext());
        strUserId = sharedPrefManager.getUserId();
        strNotificationId = getArguments().getString(Constant.NOTIFICATION_ID);
        strNotificationTitle = getArguments().getString(Constant.NOTIFICATION_TITLE);
        strNotification = getArguments().getString(Constant.NOTIFICATION_CONTENT);
        strNotificationDate = getArguments().getString(Constant.NOTIFICATION_DATE);
        tvNotificationReadTitle.setText(strNotificationTitle);
        tvNotificationRead.setText(strNotification);
        tvNotificationReadDate.setText(strNotificationDate);
        callNotificationReadApi();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(FragmentNotificationReadViewModel.class);
        // TODO: Use the ViewModel
    }
    public void callNotificationReadApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("user_id", strUserId);
            paramObject.put("notification_id", strNotificationId);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelNotificationRead> call = api.getNotificationRead(gsonObject);
            call.enqueue(new Callback<ModelNotificationRead>() {
                @Override
                public void onResponse(Call<ModelNotificationRead> call, Response<ModelNotificationRead> response) {
                    ModelNotificationRead modelNotificationRead = response.body();
                    if (modelNotificationRead.getStatus().getStatuscode().equals("200")) {
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).callGetNotificationCountApi();
                        }
                        Log.d(TAG, "Success: " + modelNotificationRead.getMessage().getMessage());
                    }
                }

                @Override
                public void onFailure(Call<ModelNotificationRead> call, Throwable t) {
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}