package com.ca_dreamers.cadreamers.adapter.my_course;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.models.my_orders.course_details.chapters.Datum;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class AdapterCourseDetailsChapter extends RecyclerView.Adapter<AdapterCourseDetailsChapter.ChapterDetailsViewHolder> {

    private final Context tContext;
    private final List<Datum> dataList;

    public AdapterCourseDetailsChapter(List<Datum> dataList, Context tContext) {
        this.dataList = dataList;
        this.tContext = tContext;
    }
    @NonNull
    @Override
    public ChapterDetailsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_chapter, viewGroup, false);
        return new ChapterDetailsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChapterDetailsViewHolder chapterDetailsViewHolder, final int i) {
        final Datum tModel = dataList.get(i);
        final String strChapterName = tModel.getChapterName();
        chapterDetailsViewHolder.tvChapterTitle.setText(strChapterName);
        chapterDetailsViewHolder.llChapterItem.setOnClickListener(v -> selectVideoAlert(tModel));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ChapterDetailsViewHolder extends RecyclerView.ViewHolder{
        @SuppressLint("NonConstantResourceId")
        @BindView(R.id.tvChapterTitle)
        protected TextView tvChapterTitle;

        @SuppressLint("NonConstantResourceId")
        @BindView(R.id.llChapterItem)
        protected LinearLayout llChapterItem;

        public ChapterDetailsViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public void selectVideoAlert(Datum tModel)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(tContext);
        builder.setTitle(tModel.getChapterName());

        LayoutInflater inflater = (LayoutInflater) tContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View customLayout = inflater.inflate(R.layout.item_chapter_detail, null);
        RecyclerView rvChapterDetail = customLayout.findViewById(R.id.rvTopicVideo);
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                rvChapterDetail.getContext(), LinearLayoutManager.HORIZONTAL, false);

        AdapterCourseDetailsChapterDetails adapter = new AdapterCourseDetailsChapterDetails(tModel.getTopics(), tModel.getId(), tContext);
        rvChapterDetail.setLayoutManager(layoutManager);
        rvChapterDetail.setAdapter(adapter);
        builder.setView(customLayout);
        builder.setPositiveButton("X", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}
