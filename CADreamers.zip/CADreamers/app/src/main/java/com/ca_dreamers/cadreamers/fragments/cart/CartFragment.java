package com.ca_dreamers.cadreamers.fragments.cart;

import androidx.appcompat.widget.AppCompatButton;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.adapter.cart.AdapterFetchCart;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.cart.fetch_cart.ModelFetchCart;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartFragment extends Fragment {

    private SharedPrefManager sharedPrefManager;
    private String strUserId;

    @BindView(R.id.btnCheckout)
    protected AppCompatButton btnCheckout;
    @BindView(R.id.rvFetchCart)
    protected RecyclerView rvFetchCart;

    private CartViewModel mViewModel;

    public static CartFragment newInstance() {
        return new CartFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.cart_fragment, container, false);
        ButterKnife.bind(this, view);
        sharedPrefManager = new SharedPrefManager(getContext());
        strUserId = sharedPrefManager.getUserId();
        rvFetchCart.setLayoutManager(new LinearLayoutManager(getContext()));
        callFetchCartApi();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(CartViewModel.class);
        // TODO: Use the ViewModel
    }

    private void callFetchCartApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("userid", strUserId);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelFetchCart> call = api.fetchCart(gsonObject);

            call.enqueue(new Callback<ModelFetchCart>() {
                @Override
                public void onResponse(Call<ModelFetchCart> call, Response<ModelFetchCart> response) {
                    ModelFetchCart modelFetchCart = response.body();

                    btnCheckout.setVisibility(View.VISIBLE);
                    AdapterFetchCart adapterFetchCart = new AdapterFetchCart(modelFetchCart.getData().getProducts(), getContext(), getActivity());
                     rvFetchCart.setAdapter(adapterFetchCart);
                }

                @Override
                public void onFailure(Call<ModelFetchCart> call, Throwable t) {
                    btnCheckout.setVisibility(View.GONE);
                    Navigation.findNavController(getView()).navigate(R.id.bottom_courses);
                    Toast.makeText(getContext(), "Your cart is empty, please add course or book in your cart.", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.btnCheckout)
    public void btnCheckoutClicked(View view){
        Navigation.findNavController(view).navigate(R.id.nav_address);
    }

}