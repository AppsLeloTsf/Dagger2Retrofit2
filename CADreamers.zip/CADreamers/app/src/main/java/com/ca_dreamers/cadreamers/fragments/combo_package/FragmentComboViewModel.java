package com.ca_dreamers.cadreamers.fragments.combo_package;

import androidx.lifecycle.ViewModel;

public class FragmentComboViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}