package com.ca_dreamers.cadreamers.fragments.notification;

import androidx.lifecycle.ViewModel;

public class FragmentNotificationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}