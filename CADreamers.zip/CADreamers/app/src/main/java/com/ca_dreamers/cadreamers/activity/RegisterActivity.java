package com.ca_dreamers.cadreamers.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatCheckBox;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.Toast;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.login_reg.otp_match.ModelOtp;
import com.ca_dreamers.cadreamers.models.login_reg.registration.ModelRegistration;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    @BindView(R.id.etRegName)
    protected TextInputLayout etRegName;
    @BindView(R.id.etPhoneReg)
    protected TextInputLayout etPhoneReg;
    @BindView(R.id.etRegEmail)
    protected TextInputLayout etRegEmail;
    @BindView(R.id.etPasswordReg)
    protected TextInputLayout etPasswordReg;

    @BindView(R.id.cbPrivacyReg)
    protected AppCompatCheckBox cbPrivacyReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
    }

    private void callRegApi(){
        String strUserName = etRegName.getEditText().getText().toString().trim();
        String strUserMobile = etPhoneReg.getEditText().getText().toString().trim();
        String strUserEmail= etRegEmail.getEditText().getText().toString().trim();
        String strPassword = etPasswordReg.getEditText().getText().toString().trim();
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("name", strUserName);
            paramObject.put("mobile", strUserMobile);
            paramObject.put("email", strUserEmail);
            paramObject.put("password", strPassword);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelRegistration> userCall = api.getRegister(gsonObject);
            userCall.enqueue(new Callback<ModelRegistration>() {
                @Override
                public void onResponse(Call<ModelRegistration> call, Response<ModelRegistration> response) {
                   ModelRegistration modelRegistration = response.body();
                   String strOtp = String.valueOf(modelRegistration.getData().getOtp());
                    Toast.makeText(RegisterActivity.this, modelRegistration.getMessage().getMessage(), Toast.LENGTH_LONG).show();
                    Log.d(Constant.TAG, "OTP: "+strOtp);
                    Intent intent = new Intent(RegisterActivity.this, OtpActivity.class);
                    intent.putExtra(Constant.USER_NAME, strUserName);
                    intent.putExtra(Constant.USER_MOBILE, strUserMobile);
                    intent.putExtra(Constant.USER_EMAIL, strUserEmail);
                    intent.putExtra(Constant.USER_PASS, strPassword);
                    intent.putExtra(Constant.USER_OTP, strOtp);
                    startActivity(intent);
                }

                @Override
                public void onFailure(Call<ModelRegistration> call, Throwable t) {
                    Toast.makeText(RegisterActivity.this, "Email or Mobile no. already exist!", Toast.LENGTH_LONG).show();
                    Log.d("TSF_REG", "REG FAILURE: "+t.getMessage());
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @OnClick(R.id.tvGoLoginReg)
    void btnSignInClicked() {
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        finishAffinity();
    }
    @OnClick(R.id.btnSignUpReg)
    void btnSignUpRegClicked() {
        if (etRegName.getEditText().getText().toString().trim().equals("")){
            etRegName.setError("Name is required.");
        }else if(etPhoneReg.getEditText().getText().toString().trim().equals("")){
            etPhoneReg.setError("Phone number is required");
        }else if(etRegEmail.getEditText().getText().toString().trim().equals("")){
            etRegEmail.setError("Email is required.");
        }else if(etPasswordReg.getEditText().getText().toString().trim().equals("")){
            etPasswordReg.setError("Password is required");
        }
        else if (!cbPrivacyReg.isChecked()) {
            cbPrivacyReg.setError("Can't left unchecked.");
            Toast.makeText(this, "To proceed, must have to check privacy and policy.", Toast.LENGTH_SHORT).show();
        }else {
            callRegApi();
             }
    }


}