package com.ca_dreamers.cadreamers.adapter.free_videos;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.activity.VimeoPlayerActivity;
import com.ca_dreamers.cadreamers.models.free_videos.FreeVideo;
import com.ca_dreamers.cadreamers.utils.Constant;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class AdapterFreeVideosDetails extends RecyclerView.Adapter<AdapterFreeVideosDetails.CourseDetailsViewHolder> {

    private Context tContext;
    private List<FreeVideo> tModels;
    private String strCatId;

    public AdapterFreeVideosDetails(List<FreeVideo> tModels, Context tContext) {
        this.tModels = tModels;
        this.tContext = tContext;
        this.strCatId = strCatId;
    }

    @NonNull
    @Override
    public CourseDetailsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_free_video, viewGroup, false);

        return new CourseDetailsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseDetailsViewHolder courseDetailsViewHolder, final int i) {
        final FreeVideo tModel = tModels.get(i);
        final String strCourseId = tModel.getId();
        final String strCourseTitle = tModel.getName();
        final String strImage = tModel.getThumbnail();


            courseDetailsViewHolder.tvTFreeVideositle.setText(strCourseTitle);
        Glide.with(tContext)
                .load(strImage)
                .into(courseDetailsViewHolder.ivFreeVideos);
            courseDetailsViewHolder.llFreeVideo.setOnClickListener(v -> {
                Intent intent = new Intent(tContext, VimeoPlayerActivity.class);
                intent.putExtra(Constant.CONTENT_ID, tModel.getId());
                intent.putExtra(Constant.CONTENT_TITLE, tModel.getName());
                intent.putExtra(Constant.CONTENT_EMBED, tModel.getContent());
                tContext.startActivity(intent);
            });

    }

    @Override
    public int getItemCount() {
        return tModels.size();
    }

    public class CourseDetailsViewHolder extends RecyclerView.ViewHolder{
        @BindView(R.id.tvTFreeVideositle)
        protected TextView tvTFreeVideositle;
        @BindView(R.id.ivFreeVideos)
        protected ImageView ivFreeVideos;
        @BindView(R.id.llFreeVideo)
        protected RelativeLayout llFreeVideo;
        public CourseDetailsViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
