package com.ca_dreamers.cadreamers.fragments.side_nav.history;

import androidx.lifecycle.ViewModel;

public class HistoryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}