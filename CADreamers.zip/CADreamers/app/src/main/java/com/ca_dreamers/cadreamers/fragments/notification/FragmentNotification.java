package com.ca_dreamers.cadreamers.fragments.notification;

import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.adapter.notification.AdapterNotification;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.notification.ModelNotification;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentNotification extends Fragment {

    private SharedPrefManager sharedPrefManager;
    private String strUserId;


    @BindView(R.id.rvNotification)
    protected RecyclerView rvNotification;

    private FragmentNotificationViewModel mViewModel;

    public static FragmentNotification newInstance() {
        return new FragmentNotification();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notification, container, false);
        ButterKnife.bind(this, view);
        sharedPrefManager = new SharedPrefManager(getContext());
        strUserId = sharedPrefManager.getUserId();
        rvNotification.setLayoutManager(new LinearLayoutManager(getContext()));
        callGetNotificationApi();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(FragmentNotificationViewModel.class);
        // TODO: Use the ViewModel
    }
    public void callGetNotificationApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("user_id", strUserId);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelNotification> call = api.getNotification(gsonObject);

            call.enqueue(new Callback<ModelNotification>() {
                @Override
                public void onResponse(Call<ModelNotification> call, Response<ModelNotification> response) {
                    ModelNotification modelNotification = response.body();
                    AdapterNotification adapterNotification = new AdapterNotification(modelNotification.getData(), getContext());
                    rvNotification.setAdapter(adapterNotification);

                }


                @Override
                public void onFailure(Call<ModelNotification> call, Throwable t) {
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}