package com.ca_dreamers.cadreamers.fragments.side_nav.my_books.books_details;

import androidx.lifecycle.ViewModel;

public class MyOdersBooksDetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}