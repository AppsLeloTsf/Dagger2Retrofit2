package com.ca_dreamers.cadreamers.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.login_reg.login.ModelLogin;
import com.ca_dreamers.cadreamers.models.login_reg.password.ModelForgotPassword;
import com.ca_dreamers.cadreamers.models.login_reg.password.update_pass.ModelUpdatePassword;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private String strOtp;
    private Context tContext;
    private AlertDialog dialogForgotPass;
    private AlertDialog dialog;
    private SharedPrefManager sharedPrefManager;
    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.etUserNameLogin)
    protected TextInputLayout etUserNameLogin;
    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.etPasswordLogin)
    protected TextInputLayout etPasswordLogin;
    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.btnSignInLogin)
    protected AppCompatButton btnSignInLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        tContext = getApplicationContext();
        sharedPrefManager = new SharedPrefManager(tContext);
    }

    private void callLoginApi(){
        String strUserName = Objects.requireNonNull(etUserNameLogin.getEditText()).getText().toString().trim();
        String strPassword = Objects.requireNonNull(etPasswordLogin.getEditText()).getText().toString().trim();
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("email", strUserName);
            paramObject.put("password", strPassword);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelLogin> userCall = api.getLogin(gsonObject);

            userCall.enqueue(new Callback<ModelLogin>() {
                @Override
                public void onResponse(@NotNull Call<ModelLogin> call, @NotNull Response<ModelLogin> response) {
                    ModelLogin modelLogin = response.body();
                    assert modelLogin != null;
                    if(modelLogin.getStatus().getStatuscode().equals("200")) {
                        String strUserId = modelLogin.getData().getId();
                        String strUserName = modelLogin.getData().getUsername();
                        String strUserMobile = modelLogin.getData().getPhone();
                        String strUserEmail = modelLogin.getData().getEmail();
                        String strUserPic = modelLogin.getData().getPicture();
                        sharedPrefManager.setUserData(strUserId, strUserName, strUserMobile, strUserEmail, strUserPic);
                        btnSignInLogin.setEnabled(false);
                        Toast.makeText(tContext, modelLogin.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(tContext, MainActivity.class);
                        intent.putExtra(Constant.USER_PRO_PIC, modelLogin.getData().getPicture());
                        startActivity(intent);
                        finishAffinity();
                    }
                    else {
                        Toast.makeText(tContext, modelLogin.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onFailure(@NotNull Call<ModelLogin> call, @NotNull Throwable t) {
                    Toast.makeText(tContext, "Credentials is invalid.", Toast.LENGTH_LONG).show();

                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("NonConstantResourceId")
    @OnClick(R.id.btnSignInLogin)
   void btnSignInLoginClicked() {
        if (Objects.requireNonNull(etUserNameLogin.getEditText()).getText().toString().trim().equals("")){
            etUserNameLogin.setError("Name is required.");
        }else if(Objects.requireNonNull(etPasswordLogin.getEditText()).getText().toString().trim().equals("")){
            etPasswordLogin.setError("Phone number is required");
        }else  {
            callLoginApi();
        }
    }
    @SuppressLint("NonConstantResourceId")
    @OnClick(R.id.tvGoRegLogin)
   void btnSignUpLoginClicked() {
        startActivity(new Intent(tContext, RegisterActivity.class));
    }
  @SuppressLint("NonConstantResourceId")
  @OnClick(R.id.tvForgotPassword)
   void tvForgotPasswordClicked() {
      AlertDialog.Builder builder = new AlertDialog.Builder(tContext);
      final View customLayout = getLayoutInflater().inflate(R.layout.custom_pass_forgot, null);
      builder.setView(customLayout);
                  TextInputLayout etForgotPassEmail = customLayout.findViewById(R.id.etForgotPassword);
                  AppCompatButton btnForgotPass = customLayout.findViewById(R.id.btnForgotPass);
                  btnForgotPass.setOnClickListener(v -> callApiForgotPass(etForgotPassEmail.getEditText().getText().toString()));

      dialogForgotPass = builder.create();
      dialogForgotPass.show();
  }

  private void callApiForgotPass(String strUserEmail)
    {
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("email", strUserEmail);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelForgotPassword> userCall = api.forgotPassword(gsonObject);

            userCall.enqueue(new Callback<ModelForgotPassword>() {
                @Override
                public void onResponse(@NotNull Call<ModelForgotPassword> call, @NotNull Response<ModelForgotPassword> response) {
                    ModelForgotPassword modelForgotPassword = response.body();
                    assert modelForgotPassword != null;
                    strOtp = String.valueOf(modelForgotPassword.getData().getOtp());
                       updatePassAlert(strUserEmail, strOtp);
                       dialogForgotPass.dismiss();
                       Toast.makeText(tContext, modelForgotPassword.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                }
                @Override
                public void onFailure(@NotNull Call<ModelForgotPassword> call, @NotNull Throwable t) {
                    Log.d("TSF_FORGOT_PASS", "RESPONSE FAILURE: "+t.getMessage());
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void updatePassAlert(String strEmail, String strOtp)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setCancelable(false);
        final View customLayout = getLayoutInflater().inflate(R.layout.custom_pass_update, null);
        builder.setView(customLayout);

        TextInputLayout etOTPPass = customLayout.findViewById(R.id.etOTPPass);
        TextInputLayout etPasswordUpdate = customLayout.findViewById(R.id.etPasswordUpdate);
        TextInputLayout etPasswordUpdateAgain = customLayout.findViewById(R.id.etPasswordUpdateAgain);
        AppCompatButton btnForgotPass = customLayout.findViewById(R.id.btnPassUpdate);
        AppCompatButton btnPassUpdateCancel = customLayout.findViewById(R.id.btnPassUpdateCancel);
        btnForgotPass.setOnClickListener(v -> {
            if (Objects.requireNonNull(etOTPPass.getEditText()).getText().toString().equals(strOtp)){
                String strEtPassUpdate = Objects.requireNonNull(etPasswordUpdate.getEditText()).getText().toString();
                String strEtPassUpdateAgain = Objects.requireNonNull(etPasswordUpdateAgain.getEditText()).getText().toString();
                if (strEtPassUpdate.equals(strEtPassUpdateAgain)){
                    callApiUpdatePass(strEmail, strEtPassUpdate);
                }
            }
            else {
                Toast.makeText(tContext, "Otp did not match", Toast.LENGTH_SHORT).show();
            }
        });

        btnPassUpdateCancel.setOnClickListener(v -> dialog.dismiss());
        dialog = builder.create();
        dialog.show();
    }

    private void callApiUpdatePass(String strUserEmail, String strPassword)
    {
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("email", strUserEmail);
            paramObject.put("password", strPassword);
            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelUpdatePassword> userCall = api.updatePassword(gsonObject);
            userCall.enqueue(new Callback<ModelUpdatePassword>() {
                @Override
                public void onResponse(@NotNull Call<ModelUpdatePassword> call, @NotNull Response<ModelUpdatePassword> response) {
                    ModelUpdatePassword modelUpdatePassword = response.body();
                    dialog.dismiss();
                    Toast.makeText(tContext, modelUpdatePassword.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                }
                @Override
                public void onFailure(@NotNull Call<ModelUpdatePassword> call, @NotNull Throwable t) {
                    Log.d("TSF_UPDATE_PASS", "RESPONSE FAILURE: "+t.getMessage());
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}