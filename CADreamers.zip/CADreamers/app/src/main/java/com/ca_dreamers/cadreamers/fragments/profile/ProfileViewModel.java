package com.ca_dreamers.cadreamers.fragments.profile;

import androidx.lifecycle.ViewModel;

public class ProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}