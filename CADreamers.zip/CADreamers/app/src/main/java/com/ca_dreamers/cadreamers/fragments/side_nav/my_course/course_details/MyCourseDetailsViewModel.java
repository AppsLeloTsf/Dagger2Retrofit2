package com.ca_dreamers.cadreamers.fragments.side_nav.my_course.course_details;

import androidx.lifecycle.ViewModel;

public class MyCourseDetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}