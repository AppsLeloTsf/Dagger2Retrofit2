package com.ca_dreamers.cadreamers.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.github.barteksc.pdfviewer.PDFView;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PdfActivityRender extends AppCompatActivity{

//    private RemotePDFViewPager remotePDFViewPager;
//    private PDFPagerAdapter pdfPagerAdapter;

//    @SuppressLint("NonConstantResourceId")
//    @BindView(R.id.clConstraint)
//    protected ConstraintLayout clConstraint;

    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.idPDFView)
    protected PDFView idPDFView;

//    @SuppressLint("NonConstantResourceId")
//    @BindView(R.id.pdfLayout)
//    protected LinearLayout pdfLayout;

    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.progressBar)
    protected ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_pdf);
        ButterKnife.bind(this);
        progressBar.setVisibility(View.VISIBLE);

        String urlPdf = getIntent().getStringExtra(Constant.BOOKS_PDF_URL);

        new Thread(() -> {
            // do your stuff
            InputStream inputStream = null;
            try {
                URL url = new URL(urlPdf);
                // below is the step where we are
                // creating our connection.
                HttpURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
                if (urlConnection.getResponseCode() == 200) {
                    // response is success.
                    // we are getting input stream from url
                    // and storing it in our variable.
                    inputStream = new BufferedInputStream(urlConnection.getInputStream());
                }

            } catch (IOException e) {
                // this is the method
                // to handle errors.
                e.printStackTrace();
            }
            InputStream finalInputStream = inputStream;
            runOnUiThread(() -> {
                idPDFView.fromStream(finalInputStream).load();
                progressBar.setVisibility(View.GONE);

            });
        }).start();
//        remotePDFViewPager = new RemotePDFViewPager(this, url, this);
    }

//    @Override
//    public void onSuccess(String url, String destinationPath) {
//        pdfPagerAdapter = new PDFPagerAdapter(this, FileUtil.extractFileNameFromURL(url));
//        remotePDFViewPager.setAdapter(pdfPagerAdapter);
//        updateLayout();
//        progressBar.setVisibility(View.GONE);
//    }
//    private void updateLayout() {
//        pdfLayout.addView(remotePDFViewPager,
//                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
//    }
//
//    @Override
//    public void onFailure(Exception e) {
//
//    }
//
//    @Override
//    public void onProgressUpdate(int progress, int total) {
//
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//
//        if (pdfPagerAdapter != null) {
//            pdfPagerAdapter.close();
//        }
//    }

}