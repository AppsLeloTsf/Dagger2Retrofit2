package com.ca_dreamers.cadreamers.fragments.combo_package;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.adapter.cart.AdapterFetchCart;
import com.ca_dreamers.cadreamers.adapter.combo_package.AdapterComboPackage;
import com.ca_dreamers.cadreamers.adapter.top_20.AdapterTop20List;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.cart.fetch_cart.ModelFetchCart;
import com.ca_dreamers.cadreamers.models.combo_package.ModelCombo;
import com.ca_dreamers.cadreamers.models.top_20.ModelTop20;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentCombo extends Fragment {
    @BindView(R.id.rvComboPackage)
    protected RecyclerView rvComboPackage;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_combo, container, false);
        ButterKnife.bind(this, view);
        rvComboPackage.setLayoutManager(new LinearLayoutManager(getContext()));
        callComboApi();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }
    private void callComboApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("type", "package");

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelCombo> call = api.getComboPackage(gsonObject);

            call.enqueue(new Callback<ModelCombo>() {
                @Override
                public void onResponse(Call<ModelCombo> call, Response<ModelCombo> response) {
                    ModelCombo modelFetchCart = response.body();

                    AdapterComboPackage adapterComboPackage = new AdapterComboPackage(modelFetchCart.getData());
                    rvComboPackage.setAdapter(adapterComboPackage);
                }

                @Override
                public void onFailure(Call<ModelCombo> call, Throwable t) {

                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}