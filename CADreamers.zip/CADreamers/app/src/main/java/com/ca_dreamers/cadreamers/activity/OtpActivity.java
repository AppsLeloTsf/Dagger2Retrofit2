package com.ca_dreamers.cadreamers.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.login_reg.otp_match.ModelOtp;
import com.ca_dreamers.cadreamers.models.login_reg.registration.ModelRegistration;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OtpActivity extends AppCompatActivity {

    private static int OTP_TIME = 1000;
    String strUserName;
    String strUserMobile;
    String strUserEmail;
    String strUserPassword;
    String strUserOtp;
    String strUserOtpMatch;
    @BindView(R.id.tvOtpMobile)
    protected AppCompatTextView tvOtpMobile;
    @BindView(R.id.etOtpNumber)
    protected AppCompatEditText etOtpNumber;
    @BindView(R.id.tvOtpResend)
    protected TextView tvOtpResend;
    @BindView(R.id.btnOtpSubmit)
    protected AppCompatButton btnOtpSubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        ButterKnife.bind(this);
        strUserName = getIntent().getStringExtra(Constant.USER_NAME);
        strUserMobile = getIntent().getStringExtra(Constant.USER_MOBILE);
        strUserEmail = getIntent().getStringExtra(Constant.USER_EMAIL);
        strUserPassword = getIntent().getStringExtra(Constant.USER_PASS);
        strUserOtp = getIntent().getStringExtra(Constant.USER_OTP);
        tvOtpMobile.setText("Otp sent to your registered mobile number "+strUserMobile);
        tvOtpResend.setEnabled(false);
        init();

    }
    private void callRegSuccessApi(){

        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("name", strUserName);
            paramObject.put("mobile", strUserMobile);
            paramObject.put("email", strUserEmail);
            paramObject.put("password", strUserPassword);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Log.d(Constant.TAG, "Request: "+gsonObject);
            Call<ModelOtp> userCall = api.getRegisterSuccess(gsonObject);
            userCall.enqueue(new Callback<ModelOtp>() {
                @Override
                public void onResponse(Call<ModelOtp> call, Response<ModelOtp> response) {
                    ModelOtp modelOtp = response.body();
                    Toast.makeText(OtpActivity.this, modelOtp.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d(Constant.TAG, "OTP: "+modelOtp.getMessage().getMessage());
                    startActivity(new Intent(OtpActivity.this, LoginActivity.class));

                }
                @Override
                public void onFailure(Call<ModelOtp> call, Throwable t) {
                    Boolean callExecuted = call.isExecuted();
                    Log.d(Constant.TAG, "REG FAILURE: "+callExecuted+"\n"+t.getMessage());
                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.btnOtpSubmit)
    public void btnOtpSubmitClicked(){
        if (etOtpNumber.getText().toString().trim().equals("")){
            etOtpNumber.setError("Please enter the OTP.");
        }else {
            strUserOtpMatch = etOtpNumber.getText().toString().trim();
            if (strUserOtpMatch.equals(strUserOtp)){
                callRegSuccessApi();
            }else{
                Toast.makeText(this, "Please enter correct otp.", Toast.LENGTH_SHORT).show();
            }
        }

    }

    @OnClick(R.id.tvOtpResend)
    public void tvOtpResendClicked(){
      callRegApi();
    }
    private void init() {
        new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {

                // Used for formatting digit to be in 2 digits only

                NumberFormat f = new DecimalFormat("00");

                long hour = (millisUntilFinished / 3600000) % 24;

                long min = (millisUntilFinished / 60000) % 60;

                long sec = (millisUntilFinished / 1000) % 60;

                tvOtpResend.setText("Request again after " + f.format(sec)+" seconds.");

            }

            // When the task is over it will print 00:00:00 there

            public void onFinish() {

                tvOtpResend.setText("Resend Otp");

            }

        }.start();

    }
    private void callRegApi(){

        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("name", strUserName);
            paramObject.put("mobile", strUserMobile);
            paramObject.put("email", strUserEmail);
            paramObject.put("password", strUserPassword);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelRegistration> userCall = api.getRegister(gsonObject);
            userCall.enqueue(new Callback<ModelRegistration>() {
                @Override
                public void onResponse(Call<ModelRegistration> call, Response<ModelRegistration> response) {
                    ModelRegistration modelRegistration = response.body();
                     strUserOtp  = String.valueOf(modelRegistration.getData().getOtp());

                    Toast.makeText(OtpActivity.this, modelRegistration.getMessage().getMessage(), Toast.LENGTH_LONG).show();
                    Log.d(Constant.TAG, "RESEND SUCCESS: " + modelRegistration.getData().getOtp());
                    tvOtpResend.setEnabled(false);
                    init();
                }

                @Override
                public void onFailure(Call<ModelRegistration> call, Throwable t) {

                }
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}