package com.ca_dreamers.cadreamers.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ca_dreamers.cadreamers.R;

public class UpdatePassActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_pass);
    }
}