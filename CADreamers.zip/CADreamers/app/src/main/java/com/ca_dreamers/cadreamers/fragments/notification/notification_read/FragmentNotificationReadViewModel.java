package com.ca_dreamers.cadreamers.fragments.notification.notification_read;

import androidx.lifecycle.ViewModel;

public class FragmentNotificationReadViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}