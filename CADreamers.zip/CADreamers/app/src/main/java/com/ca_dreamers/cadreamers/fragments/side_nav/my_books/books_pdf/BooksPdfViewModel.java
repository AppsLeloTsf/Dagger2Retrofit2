package com.ca_dreamers.cadreamers.fragments.side_nav.my_books.books_pdf;

import androidx.lifecycle.ViewModel;

public class BooksPdfViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}