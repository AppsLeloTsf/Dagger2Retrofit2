package com.ca_dreamers.cadreamers.fragments.side_nav.feedback;

import androidx.lifecycle.ViewModel;

public class FeedbackViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}