package com.ca_dreamers.cadreamers.fragments.books;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.activity.MainActivity;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.books.book_details.ModelBooksDetails;
import com.ca_dreamers.cadreamers.models.books.product_type.ModelBookMode;
import com.ca_dreamers.cadreamers.models.cart.add_cart.ModelAddCart;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class FragmentBooksDetails extends Fragment implements View.OnClickListener {

    private SharedPrefManager sharedPrefManager;
    private Context tContext;
    private AlertDialog dialog;
    private String strUserId;
    private String strId;
    private String strImage;
    private String strTitle;
    private String strDescription;
    private String strDescriptionFull;
    private String strPrice = " ";
    private String strMrp;
    private String strDiscount;
    private String strPurchased;
    private String strProdType = " ";
    private String strProdLang;


    @BindView(R.id.btnBuyBooks)
    protected AppCompatButton btnBuyBooks;
    @BindView(R.id.rgBookMode)
    protected RadioGroup rgBookMode;

    @BindView(R.id.btnShowBookMode)
    protected AppCompatButton btnShowBookMode;
    @BindView(R.id.btnHideBookMode)
    protected AppCompatButton btnHideBookMode;
    @BindView(R.id.btnViewBooks)
    protected AppCompatButton btnViewBooks;
    @BindView(R.id.ivBooksDetailsView)
    protected ImageView ivBooksDetailsView;
    @BindView(R.id.tvBooksDescriptionShort)
    protected TextView tvBooksDescriptionShort;
    @BindView(R.id.tvBooksDescription)
    protected TextView tvBooksDescription;
    @BindView(R.id.btnShowMoreBooksDescription)
    protected AppCompatButton btnShowMoreBooksDescription;
    @BindView(R.id.btnShowLessBooksDescription)
    protected AppCompatButton btnShowLessBooksDescription;

    @BindView(R.id.rvBooks)
    protected RecyclerView rvBooks;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_books_details, container, false);
        ButterKnife.bind(this, view);

        tContext = getContext();
        sharedPrefManager = new SharedPrefManager(getContext());
        strUserId = sharedPrefManager.getUserId();
        strId = getArguments().getString(Constant.BOOKS_ID);
        strImage = getArguments().getString(Constant.BOOKS_IMAGE);
        strTitle = getArguments().getString(Constant.BOOKS_TITLE);
        strDescription = getArguments().getString(Constant.BOOKS_DESCRIPTION);
        strDescriptionFull = getArguments().getString(Constant.BOOKS_DESCRIPTION_FULL);
        strMrp = getArguments().getString(Constant.BOOKS_MRP);
        strDiscount = getArguments().getString(Constant.BOOKS_DISCOUNT);
        strPurchased = getArguments().getString(Constant.BOOKS_PURCHASED);
        tvBooksDescriptionShort.setText(strDescription);

        tvBooksDescription.setText(Html.fromHtml(strDescriptionFull));
        Glide.with(getContext()).load(strImage).into(ivBooksDetailsView);
        rvBooks.setLayoutManager(new LinearLayoutManager(getContext()));
        tvBooksDescriptionShort.setVisibility(View.VISIBLE);
        tvBooksDescription.setVisibility(View.GONE);
        btnShowLessBooksDescription.setVisibility(View.GONE);
        btnShowMoreBooksDescription.setVisibility(View.VISIBLE);
        if (strPurchased.equals("Purchased")){
            btnBuyBooks.setVisibility(View.GONE);
            btnViewBooks.setVisibility(View.VISIBLE);
        }else {
            btnBuyBooks.setVisibility(View.VISIBLE);
            btnViewBooks.setVisibility(View.GONE);
        }
        btnShowBookMode.setVisibility(View.VISIBLE);
        btnHideBookMode.setVisibility(View.GONE);
        rgBookMode.setVisibility(View.GONE);
        callBooksDetailsApi();
        callBookModeApi();
        return view;
    }

    private void callBooksDetailsApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("user_id", strUserId);
            paramObject.put("prod_id", strId);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelBooksDetails> call = api.getBooksDetails(gsonObject);

            call.enqueue(new Callback<ModelBooksDetails>() {
                @Override
                public void onResponse(Call<ModelBooksDetails> call, Response<ModelBooksDetails> response) {
                    ModelBooksDetails modelCourseDetail = response.body();
                    strProdLang = modelCourseDetail.getData().getLanguage();

                }


                @Override
                public void onFailure(Call<ModelBooksDetails> call, Throwable t) {

                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @OnClick(R.id.btnShowMoreBooksDescription)
    public void btnShowMoreBooksDescriptionClicked() {
        tvBooksDescriptionShort.setVisibility(View.GONE);
        tvBooksDescription.setVisibility(View.VISIBLE);
        btnShowLessBooksDescription.setVisibility(View.VISIBLE);
        btnShowMoreBooksDescription.setVisibility(View.GONE);
    }
    @OnClick(R.id.btnShowLessBooksDescription)
    public void btnShowLessBooksDescriptionClicked() {
        tvBooksDescriptionShort.setVisibility(View.VISIBLE);
        tvBooksDescription.setVisibility(View.GONE);
        btnShowLessBooksDescription.setVisibility(View.GONE);
        btnShowMoreBooksDescription.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.btnBuyBooks)
    public void btnBuyBooksClicked(View view) {
        if (strPrice.equals(" ")) {
            Toast.makeText(getContext(), "Please select the mode of Book", Toast.LENGTH_SHORT).show();
            btnShowBookMode.setVisibility(View.GONE);
            btnHideBookMode.setVisibility(View.VISIBLE);
            rgBookMode.setVisibility(View.VISIBLE);
        }
        else {
                callCartAddApi(view, strProdType);
                btnBuyBooks.setEnabled(false);
            btnShowBookMode.setVisibility(View.VISIBLE);
            btnHideBookMode.setVisibility(View.GONE);
            rgBookMode.setVisibility(View.VISIBLE);
        }

    }

    @OnClick(R.id.btnShowBookMode)
    public void btnShowBookModeClicked(View view) {
        btnShowBookMode.setVisibility(View.GONE);
        btnHideBookMode.setVisibility(View.VISIBLE);
        rgBookMode.setVisibility(View.VISIBLE);
    }
    @OnClick(R.id.btnHideBookMode)
    public void btnHideBookModeClicked(View view) {
        btnShowBookMode.setVisibility(View.VISIBLE);
        btnHideBookMode.setVisibility(View.GONE);
        rgBookMode.setVisibility(View.GONE);
    }
    @OnClick(R.id.btnViewBooks)
    public void btnViewBooksClicked(View view) {
        Bundle bundle = new Bundle();
        bundle.putString(Constant.BOOKS_ID, strId);
        bundle.putString(Constant.BOOKS_IMAGE, strImage);
        bundle.putString(Constant.BOOKS_TITLE, strTitle);
        bundle.putString(Constant.BOOKS_DESCRIPTION, strDescription);
        Navigation.findNavController(view).navigate(R.id.nav_purchased_Books_Details, bundle);

    }


    private void callBookModeApi(){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();
            paramObject.put("product_id", strId);
            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelBookMode> call = api.getBooksMode(gsonObject);

            call.enqueue(new Callback<ModelBookMode>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onResponse(Call<ModelBookMode> call, Response<ModelBookMode> response) {
                    ModelBookMode modelBookMode = response.body();
                    rgBookMode.setOrientation(LinearLayout.VERTICAL);
                    int number = modelBookMode.getData().getList().size();

                    //
                    for (int i = 0; i < number; i++) {
                        RadioButton rdbtn = new RadioButton(tContext);
                        rdbtn.setId(View.generateViewId());
                        rdbtn.setText(modelBookMode.getData().getList().get(i).getModeD()+", ₹"+
                                modelBookMode.getData().getList().get(i).getPrice());
                        rdbtn.setTextSize(12);

                        rgBookMode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                           @Override
                           public void onCheckedChanged(RadioGroup rg, int checkedId) {
                               for (int i = 0; i < rg.getChildCount(); i++) {
                                   RadioButton btn = (RadioButton) rg.getChildAt(i);
                                   if (btn.getId() == checkedId) {
                                       String text = btn.getText().toString();
                                       // do something with text

                                       strProdType = modelBookMode.getData().getList().get(i).getModeD();
                                       strPrice = modelBookMode.getData().getList().get(i).getPrice();
                                       Log.d(Constant.TAG, "Price: " + strPrice + " " + strProdType + " \nChecked Id:" + checkedId);
                                       return;
                                   }
                               }
                           }
                       });
                        rgBookMode.addView(rdbtn);
                    }
                }

                @Override
                public void onFailure(Call<ModelBookMode> call, Throwable t) {

                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void callCartAddApi(View view, String strProdType){
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("price", strPrice);
            paramObject.put("languagename", strProdLang);
            paramObject.put("producttype", strProdType);
            paramObject.put("productid", strId);
            paramObject.put("userid", strUserId);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelAddCart> call = api.addCart(gsonObject);
            call.enqueue(new Callback<ModelAddCart>() {
                @Override
                public void onResponse(Call<ModelAddCart> call, Response<ModelAddCart> response) {
                    ModelAddCart modelCourseDetail = response.body();
                    if (modelCourseDetail.getStatus().getStatuscode().equals("200")) {
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity)getActivity()).callFetchCartApi();
                        }
                        Navigation.findNavController(view).navigate(R.id.menu_cart);
                        btnBuyBooks.setEnabled(true);
                    }
                }

                @Override
                public void onFailure(Call<ModelAddCart> call, Throwable t) {
                    Log.d("TSF_CART", t.getMessage());
                    btnBuyBooks.setEnabled(true);
                    btnShowBookMode.setVisibility(View.VISIBLE);
                    btnHideBookMode.setVisibility(View.GONE);
                    rgBookMode.setVisibility(View.GONE);
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onClick(View v) {
        Log.d(Constant.TAG, " Name " + ((RadioButton)v).getText() +" Id is "+v.getId());
    }

}