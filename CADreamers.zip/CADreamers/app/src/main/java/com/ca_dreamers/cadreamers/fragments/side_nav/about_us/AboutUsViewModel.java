package com.ca_dreamers.cadreamers.fragments.side_nav.about_us;

import androidx.lifecycle.ViewModel;

public class AboutUsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}