package com.ca_dreamers.cadreamers.fragments.side_nav.my_books;

import androidx.lifecycle.ViewModel;

public class MyBooksViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}