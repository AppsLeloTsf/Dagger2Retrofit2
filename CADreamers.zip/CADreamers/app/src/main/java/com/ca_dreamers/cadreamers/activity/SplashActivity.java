package com.ca_dreamers.cadreamers.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SplashActivity extends AppCompatActivity {
    private SharedPrefManager sharedPrefManager;
    private Context tContext;

    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.pbSplashScreen)
    protected ProgressBar pbSplashScreen;
    @SuppressLint("NonConstantResourceId")
    @BindView(R.id.ivSplashScreen)
    protected ImageView ivSplashScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ButterKnife.bind(this);
        pbSplashScreen.setVisibility(View.VISIBLE);
        ivSplashScreen.setVisibility(View.GONE);
        tContext = getApplicationContext();
        sharedPrefManager = new SharedPrefManager(tContext);
        init();
    }
    private void init() {

        Handler handler = new Handler();
        int SPLASH_TIME_OUT = 3000;
        handler.postDelayed(() -> {
            handler.postDelayed(() -> {
                if (!sharedPrefManager.getUserId().equals("")) {
                    Intent intent = new Intent(tContext, MainActivity.class);
                    startActivity(intent);
                    finish();
                }else {
                    Intent intent = new Intent(tContext, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }

            }, 1500);
            pbSplashScreen.setVisibility(View.GONE);
            ivSplashScreen.setVisibility(View.VISIBLE);
        }, SPLASH_TIME_OUT);
    }

}