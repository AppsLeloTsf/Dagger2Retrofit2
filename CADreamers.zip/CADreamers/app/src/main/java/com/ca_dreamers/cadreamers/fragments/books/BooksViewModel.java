package com.ca_dreamers.cadreamers.fragments.books;

import androidx.lifecycle.ViewModel;

public class BooksViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}