package com.ca_dreamers.cadreamers.fragments.address.update_address;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.FileProvider;
import androidx.lifecycle.ViewModelProvider;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.ca_dreamers.cadreamers.R;
import com.ca_dreamers.cadreamers.api.Api;
import com.ca_dreamers.cadreamers.api.RetrofitClient;
import com.ca_dreamers.cadreamers.models.address.add_update_address.ModelAddUpdateAddress;
import com.ca_dreamers.cadreamers.storage.SharedPrefManager;
import com.ca_dreamers.cadreamers.utils.Constant;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.ca_dreamers.cadreamers.utils.Constant.TAG;

public class UpdateAddressFragment extends Fragment {

    private static final int REQUEST_CODE = 101;
    public static final int REQUEST_IMAGE = 100;
    public static final String INTENT_IMAGE_PICKER_OPTION = "image_picker_option";
    public static final String INTENT_ASPECT_RATIO_X = "aspect_ratio_x";
    public static final String INTENT_ASPECT_RATIO_Y = "aspect_ratio_Y";
    public static final String INTENT_LOCK_ASPECT_RATIO = "lock_aspect_ratio";
    public static final String INTENT_IMAGE_COMPRESSION_QUALITY = "compression_quality";
    public static final String INTENT_SET_BITMAP_MAX_WIDTH_HEIGHT = "set_bitmap_max_width_height";
    public static final String INTENT_BITMAP_MAX_WIDTH = "max_width";
    public static final String INTENT_BITMAP_MAX_HEIGHT = "max_height";


    public static final int REQUEST_IMAGE_CAPTURE = 0;
    public static final int REQUEST_GALLERY_IMAGE = 1;

    private boolean lockAspectRatio = false, setBitmapMaxWidthHeight = false;
    private int ASPECT_RATIO_X = 16, ASPECT_RATIO_Y = 9, bitmapMaxWidth = 1000, bitmapMaxHeight = 1000;
    private int IMAGE_COMPRESSION = 80;
    public static String fileName;

    public interface PickerOptionListener {
        void onTakeCameraSelected();

        void onChooseGallerySelected();
    }
    private View view;
    private SharedPrefManager sharedPrefManager;
    private String strUserId;
    private String strAddId;
    private String strAddName;
    private String strAddMobile;
    private String strAddAddress;
    private String strAddCity;
    private String strAddState;
    private String strAddCountry;
    private String strAddPinCode;
    private String strAddAdhar;
    private String strAction;
    private UpdateAddressViewModel mViewModel;

    @BindView(R.id.etAddAddressName)
    protected EditText etAddAddressName;
    @BindView(R.id.etAddAddressPhone)
    protected EditText etAddAddressPhone;
    @BindView(R.id.etAddAddressAddress)
    protected EditText etAddAddressAddress;
    @BindView(R.id.etAddAddressCity)
    protected EditText etAddAddressCity;
    @BindView(R.id.etAddAddressState)
    protected EditText etAddAddressState;
    @BindView(R.id.etAddAddressCountry)
    protected EditText etAddAddressCountry;
    @BindView(R.id.etAddAddressPinCode)
    protected EditText etAddAddressPinCode;
    @BindView(R.id.ivUploadId)
    protected ImageView ivAddAddressAdhar;
    @BindView(R.id.btnAddAddressSubmit)
    protected AppCompatButton btnAddAddressSubmit;

    public static UpdateAddressFragment newInstance() {
        return new UpdateAddressFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_update_address, container, false);
        ButterKnife.bind(this, view);
        sharedPrefManager = new SharedPrefManager(getContext());
        strUserId = sharedPrefManager.getUserId();
        strAddId = getArguments().getString(Constant.ADDRESS_ID);
        strAction = getArguments().getString(Constant.ADDRESS_ACTION);
        etAddAddressName.setText(getArguments().getString(Constant.ADDRESS_NAME));
        etAddAddressPhone.setText(getArguments().getString(Constant.ADDRESS_MOBILE));
        etAddAddressAddress.setText(getArguments().getString(Constant.ADDRESS_ADDRESS));
//        etAddAddressCity.setText(getArguments().getString(Constant.ADDRESS_CITY));
//        etAddAddressState.setText(getArguments().getString(Constant.ADDRESS_STATE));
//        etAddAddressCountry.setText(getArguments().getString(Constant.ADDRESS_COUNTRY));
        etAddAddressPinCode.setText(getArguments().getString(Constant.ADDRESS_PIN_CODE));

        if (strAction.equals("add")){
            btnAddAddressSubmit.setText("Add");
        }else if (strAction.equals("update")){
            btnAddAddressSubmit.setText("Update");
        }
        // Clearing older images from cache directory
        // don't call this line if you want to choose multiple images in the same activity
        // call this once the bitmap(s) usage is over
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(UpdateAddressViewModel.class);
        // TODO: Use the ViewModel
    }

    private void callAddAddressApi(){
        strAddName = etAddAddressName.getText().toString().trim();
        strAddMobile = etAddAddressPhone.getText().toString().trim();
        strAddAddress = etAddAddressAddress.getText().toString().trim();
        strAddCity = etAddAddressCity.getText().toString().trim();
        strAddState = etAddAddressState.getText().toString().trim();
        strAddPinCode = etAddAddressPinCode.getText().toString().trim();

        BitmapDrawable drawable = (BitmapDrawable) ivAddAddressAdhar.getDrawable();
        Bitmap bitmap = drawable.getBitmap();
        strAddAdhar = BitMapToString(bitmap);
        Api api = RetrofitClient.createService(Api.class, "cadreamers", "cadreamers@123");
        JsonObject gsonObject = new JsonObject();
        try {
            JSONObject paramObject = new JSONObject();

            paramObject.put("addrid", strAddId);
            paramObject.put("name", strAddName);
            paramObject.put("mobile", strAddMobile);
            paramObject.put("address", strAddAddress);
            paramObject.put("city", strAddCity);
            paramObject.put("state", strAddState);
            paramObject.put("country", strAddCountry);
            paramObject.put("pincode", strAddPinCode);
            paramObject.put("aadhar_card", strAddAdhar);
            paramObject.put("userid", strUserId);
            paramObject.put("action", strAction);

            JsonParser jsonParser = new JsonParser();
            gsonObject = (JsonObject) jsonParser.parse(paramObject.toString());
            Call<ModelAddUpdateAddress> call = api.addUpdateAddress(gsonObject);

            call.enqueue(new Callback<ModelAddUpdateAddress>() {
                @Override
                public void onResponse(Call<ModelAddUpdateAddress> call, Response<ModelAddUpdateAddress> response) {
                    ModelAddUpdateAddress modelAddUpdateAddress = response.body();
                    if (modelAddUpdateAddress.getStatus().getStatuscode().equals("200")){
                        Navigation.findNavController(view).popBackStack(R.id.nav_address, false);
                        Toast.makeText(getContext(), modelAddUpdateAddress.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                        btnAddAddressSubmit.setEnabled(true);
                    }
                    else {
                        Toast.makeText(getContext(), modelAddUpdateAddress.getMessage().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ModelAddUpdateAddress> call, Throwable t) {

                    Log.d(TAG, "Addrerr Failure: "+t.getMessage());
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public String BitMapToString(Bitmap bitmap){
        ByteArrayOutputStream baos=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG,10, baos);
        byte [] b=baos.toByteArray();
        String temp=Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    @OnClick(R.id.ivUploadId)
    public void ivUploadIdClicked(View view){
        Dexter.withActivity(getActivity())
                .withPermissions(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        if (report.areAllPermissionsGranted()) {
                            selectImage();
                        }

                        if (report.isAnyPermissionPermanentlyDenied()) {
                            showSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();
    }

    private void selectImage() {
        final CharSequence[] options = { "Take Photo", "Choose from Gallery","Cancel" };
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo"))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");

                    Uri photoURI = FileProvider.getUriForFile(getContext(), getActivity().getApplicationContext().getPackageName() + ".provider", f);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    startActivityForResult(intent, 1);
                }
                else if (options[item].equals("Choose from Gallery"))
                {
                    Intent intent = new   Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, 2);
                }
                else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    // navigating user to app settings
    @OnClick(R.id.btnAddAddressSubmit)
    public void btnAddAddressSubmitClicked(View view){
        if (etAddAddressName.getText().equals("")){
            etAddAddressName.setError("Mandatory field can't be empty");
        }

        else if (etAddAddressPhone.getText().equals("")){
            etAddAddressPhone.setError("Mandatory field can't be empty");
        }
       else if (etAddAddressAddress.getText().equals("")){
            etAddAddressAddress.setError("Mandatory field can't be empty");
        }

       else if (etAddAddressCity.getText().equals("")){
            etAddAddressCity.setError("Mandatory field can't be empty");
        }
       else if (etAddAddressState.getText().equals("")){
            etAddAddressState.setError("Mandatory field can't be empty");
        }

       else if (etAddAddressCountry.getText().equals("")){
            etAddAddressCountry.setError("Mandatory field can't be empty");
        }
        else if (etAddAddressPinCode.getText().equals("")){
             etAddAddressPinCode.setError("Mandatory field can't be empty");
        }
        else {
             callAddAddressApi();
             btnAddAddressSubmit.setEnabled(false);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                File f = new File(Environment.getExternalStorageDirectory().toString());
                for (File temp : f.listFiles()) {
                    if (temp.getName().equals("temp.jpg")) {
                        f = temp;
                        break;
                    }
                }
                try {
                    Bitmap bitmap;
                    BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                    bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(),
                            bitmapOptions);
                    ivAddAddressAdhar.setImageBitmap(bitmap);
                    String path = android.os.Environment
                            .getExternalStorageDirectory()
                            + File.separator
                            + "Phoenix" + File.separator + "default";
                    f.delete();
                    OutputStream outFile = null;
                    File file = new File(path, String.valueOf(System.currentTimeMillis()) + ".jpg");
                    try {
                        outFile = new FileOutputStream(file);
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outFile);
                        outFile.flush();
                        outFile.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (requestCode == 2) {
                Uri selectedImage = data.getData();
                String[] filePath = { MediaStore.Images.Media.DATA };
                Cursor c = getActivity().getContentResolver().query(selectedImage,filePath, null, null, null);
                c.moveToFirst();
                int columnIndex = c.getColumnIndex(filePath[0]);
                String picturePath = c.getString(columnIndex);
                c.close();
                Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
                Log.w(TAG, picturePath+"");
                ivAddAddressAdhar.setImageBitmap(thumbnail);
            }
        }
    }
    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(getString(R.string.dialog_permission_title));
        builder.setMessage(getString(R.string.dialog_permission_message));
        builder.setPositiveButton(getString(R.string.go_to_settings), (dialog, which) -> {
            dialog.cancel();
            openSettings();
        });
        builder.setNegativeButton(getString(android.R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();

    }

    // navigating user to app settings
    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }
}