package com.ca_dreamers.cadreamers.fragments.side_nav.contact_us;

import androidx.lifecycle.ViewModel;

public class ContactUsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}